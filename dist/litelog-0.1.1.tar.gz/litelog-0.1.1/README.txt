=======
LiteLog
=======

LiteLog is an easy-to-use, totally standard-library Python logging utility that makes complex logging functions easy.

-----
Usage
-----

>>> from litelog import log
>>>